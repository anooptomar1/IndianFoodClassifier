//
//  ViewController.swift
//  IndianFoodClassifier
//
//  Created by Anoop tomar on 4/6/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit
import CoreML
import Vision

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var resultLabel: UILabel!
    
    var imagePicker: UIImagePickerController!

    var pickedImage: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker = UIImagePickerController()
        imagePicker.delegate = self
    }

    @IBAction func loadImage(sender: UIButton) {
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
        
        present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func analyzeImage(sender: UIButton) {
        let model = try! VNCoreMLModel(for: indianFood().model)
        let request = VNCoreMLRequest(model: model) { (request, error) in
            if let results = request.results as? [VNClassificationObservation], let result = results.first {
                DispatchQueue.main.async {
                    self.resultLabel.text = "\(result.identifier) \(result.confidence * 100)% \n"
                }
            }
        }
        request.imageCropAndScaleOption = .centerCrop
        DispatchQueue.global().async {
            let handler = VNImageRequestHandler(cgImage: self.pickedImage!.cgImage!, options: [:])
            do {
                try handler.perform([request])
            } catch {
                print(error)
            }
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickerImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imageView.contentMode = .scaleAspectFit
            imageView.image = pickerImage
            self.pickedImage = pickerImage
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func unusedForNow() {
        
        let model = try! VNCoreMLModel(for: indianFood().model)
        
        let request = VNCoreMLRequest(model: model) { (request, error) in
            if let results = request.results as? [VNClassificationObservation] {
                for result in results {
                    print(result)
                }
            }
        }
        request.imageCropAndScaleOption = .centerCrop
        DispatchQueue.global().async {
            let handler = VNImageRequestHandler(cgImage: #imageLiteral(resourceName: "CB").cgImage!, options: [:])
            do {
                try handler.perform([request])
            } catch {
                print(error)
            }
        }
    }

}

